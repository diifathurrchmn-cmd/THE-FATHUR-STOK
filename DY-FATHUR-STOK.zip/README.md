# DY FATHUR STOK

Aplikasi stok Android sederhana untuk:
- VARIAN YAKULT
- VARIAN TEA
- VARIAN SQUASH
- VARIAN MILKSHAKE
- CUP PCS
- CUP DUS
- BARANG BELANJA

Fitur:
- Tambah/edit/hapus barang
- Stok masuk dan stok keluar
- Pencarian barang
- Kategori tambah/edit/hapus
- Data tersimpan lokal di HP
- GitHub Actions menghasilkan `app-debug.apk`

Build:
1. Upload seluruh isi project ke repository GitHub.
2. Buka tab Actions.
3. Pilih "Build DY FATHUR STOK APK".
4. Tekan "Run workflow".
5. Setelah selesai, buka hasil workflow dan download artifact `DY-FATHUR-STOK-debug-apk`.
