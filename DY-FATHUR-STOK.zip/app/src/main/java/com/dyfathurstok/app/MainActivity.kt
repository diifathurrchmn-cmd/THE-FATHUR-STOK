package com.dyfathurstok.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

data class StockItem(
    val id: Long,
    val name: String,
    val category: String,
    val stock: Int
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DyFathurStokApp(this)
        }
    }
}

class StockStore(context: Context) {
    private val prefs = context.getSharedPreferences("dy_fathur_stok", Context.MODE_PRIVATE)
    private val defaultCategories = listOf(
        "VARIAN YAKULT", "VARIAN TEA", "VARIAN SQUASH",
        "VARIAN MILKSHAKE", "CUP PCS", "CUP DUS", "BARANG BELANJA"
    )

    fun loadCategories(): List<String> {
        val raw = prefs.getString("categories", null) ?: return defaultCategories
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { arr.getString(it) }
        }.getOrDefault(defaultCategories)
    }

    fun saveCategories(categories: List<String>) {
        val arr = JSONArray()
        categories.forEach { arr.put(it) }
        prefs.edit().putString("categories", arr.toString()).apply()
    }

    fun loadItems(): List<StockItem> {
        val raw = prefs.getString("items", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) {
                val o = arr.getJSONObject(it)
                StockItem(
                    o.getLong("id"),
                    o.getString("name"),
                    o.getString("category"),
                    o.getInt("stock")
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveItems(items: List<StockItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("name", it.name)
                put("category", it.category)
                put("stock", it.stock)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DyFathurStokApp(context: Context) {
    val store = remember { StockStore(context) }
    var categories by remember { mutableStateOf(store.loadCategories()) }
    var items by remember { mutableStateOf(store.loadItems()) }
    var search by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("SEMUA") }
    var showItemDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<StockItem?>(null) }
    var showCategoryDialog by remember { mutableStateOf(false) }
    var categoryToEdit by remember { mutableStateOf<String?>(null) }

    val filtered = items.filter {
        val matchSearch = search.isBlank() || it.name.contains(search, true)
        val matchCategory = selectedCategory == "SEMUA" || it.category == selectedCategory
        matchSearch && matchCategory
    }
    val totalStock = items.sumOf { it.stock }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("DY FATHUR STOK", fontWeight = FontWeight.Bold)
                            Text(
                                "Total stok: $totalStock",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    },
                    actions = {
                        TextButton(onClick = { showCategoryDialog = true }) {
                            Text("KATEGORI")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = {
                        editingItem = null
                        showItemDialog = true
                    }
                ) { Text("+", style = MaterialTheme.typography.headlineMedium) }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .padding(horizontal = 12.dp)
            ) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Cari barang") },
                    singleLine = true
                )

                Spacer(Modifier.height(8.dp))

                LazyColumn(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        CategorySelector(
                            categories = categories,
                            selected = selectedCategory,
                            onSelected = { selectedCategory = it }
                        )
                    }

                    if (filtered.isEmpty()) {
                        item {
                            Spacer(Modifier.height(40.dp))
                            Text("Belum ada barang.")
                            Text("Tekan + untuk menambahkan stok.")
                        }
                    } else {
                        items(filtered, key = { it.id }) { item ->
                            StockCard(
                                item = item,
                                onPlus = {
                                    items = items.map {
                                        if (it.id == item.id) it.copy(stock = it.stock + 1) else it
                                    }
                                    store.saveItems(items)
                                },
                                onMinus = {
                                    items = items.map {
                                        if (it.id == item.id) it.copy(stock = (it.stock - 1).coerceAtLeast(0)) else it
                                    }
                                    store.saveItems(items)
                                },
                                onEdit = {
                                    editingItem = item
                                    showItemDialog = true
                                },
                                onDelete = {
                                    items = items.filterNot { it.id == item.id }
                                    store.saveItems(items)
                                }
                            )
                        }
                    }
                }
            }
        }

        if (showItemDialog) {
            ItemDialog(
                categories = categories,
                initial = editingItem,
                onDismiss = { showItemDialog = false },
                onSave = { name, category, stock ->
                    val current = editingItem
                    items = if (current == null) {
                        items + StockItem(
                            System.currentTimeMillis(),
                            name.trim(),
                            category,
                            stock.coerceAtLeast(0)
                        )
                    } else {
                        items.map {
                            if (it.id == current.id) it.copy(
                                name = name.trim(),
                                category = category,
                                stock = stock.coerceAtLeast(0)
                            ) else it
                        }
                    }
                    store.saveItems(items)
                    showItemDialog = false
                }
            )
        }

        if (showCategoryDialog) {
            CategoryDialog(
                categories = categories,
                onDismiss = { showCategoryDialog = false },
                onAdd = { name ->
                    val clean = name.trim().uppercase()
                    if (clean.isNotEmpty() && !categories.contains(clean)) {
                        categories = categories + clean
                        store.saveCategories(categories)
                    }
                },
                onEdit = { old, new ->
                    val clean = new.trim().uppercase()
                    if (clean.isNotEmpty()) {
                        categories = categories.map { if (it == old) clean else it }
                        items = items.map { if (it.category == old) it.copy(category = clean) else it }
                        if (selectedCategory == old) selectedCategory = clean
                        store.saveCategories(categories)
                        store.saveItems(items)
                    }
                },
                onDelete = { cat ->
                    categories = categories.filterNot { it == cat }
                    items = items.filterNot { it.category == cat }
                    if (selectedCategory == cat) selectedCategory = "SEMUA"
                    store.saveCategories(categories)
                    store.saveItems(items)
                }
            )
        }
    }
}

@Composable
fun CategorySelector(
    categories: List<String>,
    selected: String,
    onSelected: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("Kategori", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(
                selected = selected == "SEMUA",
                onClick = { onSelected("SEMUA") },
                label = { Text("SEMUA") }
            )
            categories.take(2).forEach { cat ->
                FilterChip(
                    selected = selected == cat,
                    onClick = { onSelected(cat) },
                    label = { Text(cat) }
                )
            }
        }
        if (categories.size > 2) {
            var expanded by remember { mutableStateOf(false) }
            Box {
                TextButton(onClick = { expanded = true }) { Text("Pilih kategori lain ▼") }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    categories.drop(2).forEach { cat ->
                        DropdownMenuItem(
                            text = { Text(cat) },
                            onClick = {
                                onSelected(cat)
                                expanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StockCard(
    item: StockItem,
    onPlus: () -> Unit,
    onMinus: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(item.name, fontWeight = FontWeight.Bold)
            Text(item.category, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = onMinus) { Text("−") }
                    Text(
                        "${item.stock}",
                        modifier = Modifier.padding(horizontal = 18.dp),
                        fontWeight = FontWeight.Bold
                    )
                    Button(onClick = onPlus) { Text("+") }
                }
                Row {
                    TextButton(onClick = onEdit) { Text("EDIT") }
                    TextButton(onClick = onDelete) { Text("HAPUS") }
                }
            }
        }
    }
}

@Composable
fun ItemDialog(
    categories: List<String>,
    initial: StockItem?,
    onDismiss: () -> Unit,
    onSave: (String, String, Int) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: categories.firstOrNull().orEmpty()) }
    var stock by remember { mutableStateOf((initial?.stock ?: 0).toString()) }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Tambah Barang" else "Edit Barang") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama barang") },
                    singleLine = true
                )
                Box {
                    OutlinedButton(onClick = { expanded = true }) {
                        Text(category.ifBlank { "Pilih kategori" })
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach {
                            DropdownMenuItem(
                                text = { Text(it) },
                                onClick = { category = it; expanded = false }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = stock,
                    onValueChange = { stock = it.filter(Char::isDigit) },
                    label = { Text("Stok awal") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank() && category.isNotBlank(),
                onClick = { onSave(name, category, stock.toIntOrNull() ?: 0) }
            ) { Text("SIMPAN") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("BATAL") } }
    )
}

@Composable
fun CategoryDialog(
    categories: List<String>,
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit,
    onEdit: (String, String) -> Unit,
    onDelete: (String) -> Unit
) {
    var newCategory by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kelola Kategori") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newCategory,
                        onValueChange = { newCategory = it },
                        modifier = Modifier.weight(1f),
                        label = { Text("Kategori baru") },
                        singleLine = true
                    )
                    Spacer(Modifier.width(6.dp))
                    Button(onClick = {
                        onAdd(newCategory)
                        newCategory = ""
                    }) { Text("+") }
                }
                Spacer(Modifier.height(10.dp))
                categories.forEach { cat ->
                    if (editing == cat) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = editText,
                                onValueChange = { editText = it },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            TextButton(onClick = {
                                onEdit(cat, editText)
                                editing = null
                            }) { Text("OK") }
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(cat, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                editing = cat
                                editText = cat
                            }) { Text("EDIT") }
                            TextButton(onClick = { onDelete(cat) }) { Text("HAPUS") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("SELESAI") } }
    )
}
